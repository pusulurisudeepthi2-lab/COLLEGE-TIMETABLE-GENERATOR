import io
import streamlit as st
import pandas as pd


# ---------------------------------------------------------
# PAGE SETTINGS
# ---------------------------------------------------------

st.set_page_config(
    page_title="College Timetable Generator",
    page_icon="📚",
    layout="wide"
)

st.title("📚 College Timetable Generator")
st.write(
    "Generate a conflict-free timetable using Greedy ordering "
    "and Backtracking."
)


# ---------------------------------------------------------
# DEFAULT DATA
# ---------------------------------------------------------

DEFAULT_SUBJECTS = pd.DataFrame(
    [
        ["Python", "CSE-A", "Anita", "R101", 3],
        ["DBMS", "CSE-A", "Rahul", "R102", 3],
        ["Data Structures", "CSE-A", "Anita", "R103", 2],
        ["Mathematics", "CSE-A", "Priya", "R101", 3],
        ["English", "CSE-A", "Kiran", "R104", 2],

        ["Python", "CSE-B", "Anita", "R101", 3],
        ["DBMS", "CSE-B", "Rahul", "R102", 3],
        ["Data Structures", "CSE-B", "Anita", "R103", 2],
    ],
    columns=[
        "Subject",
        "Batch",
        "Faculty",
        "Room",
        "Classes/week"
    ]
)


# ---------------------------------------------------------
# DAYS
# ---------------------------------------------------------

DAYS = [
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday"
]


# ---------------------------------------------------------
# TIMETABLE GENERATOR
# ---------------------------------------------------------

def generate_timetable(
    subjects,
    periods_per_day,
    max_nodes=100000
):
    """
    Generate timetable using:

    1. Greedy ordering
    2. Backtracking search

    Constraints:
    - A batch cannot have two classes at the same time.
    - A faculty member cannot teach two batches at the same time.
    - A room cannot be used by two batches at the same time.
    """

    sessions = []

    # ---------------------------------------------
    # Create individual class sessions
    # ---------------------------------------------

    for _, row in subjects.iterrows():

        subject = str(row["Subject"]).strip()
        batch = str(row["Batch"]).strip()
        faculty = str(row["Faculty"]).strip()
        room = str(row["Room"]).strip()

        try:
            classes_per_week = int(row["Classes/week"])
        except:
            classes_per_week = 0

        for session_number in range(1, classes_per_week + 1):

            sessions.append(
                {
                    "Subject": subject,
                    "Batch": batch,
                    "Faculty": faculty,
                    "Room": room,
                    "Session": session_number
                }
            )

    # ---------------------------------------------
    # Greedy ordering
    #
    # Subjects requiring more classes are placed
    # earlier in the search.
    # ---------------------------------------------

    frequency = {}

    for session in sessions:

        key = (
            session["Subject"],
            session["Batch"]
        )

        frequency[key] = frequency.get(key, 0) + 1

    sessions.sort(
        key=lambda x: (
            -frequency[
                (x["Subject"], x["Batch"])
            ],
            x["Batch"],
            x["Subject"]
        )
    )

    # ---------------------------------------------
    # All available slots
    # ---------------------------------------------

    slots = []

    for day in DAYS:

        for period in range(
            1,
            periods_per_day + 1
        ):

            slots.append(
                (day, period)
            )

    # ---------------------------------------------
    # Tracking structures
    # ---------------------------------------------

    schedule = []

    batch_busy = set()
    faculty_busy = set()
    room_busy = set()

    nodes = 0
    backtracks = 0

    # ---------------------------------------------
    # Backtracking algorithm
    # ---------------------------------------------

    def backtrack(index):

        nonlocal nodes
        nonlocal backtracks

        # Solution found
        if index == len(sessions):
            return True

        # Stop if search becomes too large
        if nodes >= max_nodes:
            return False

        nodes += 1

        session = sessions[index]

        batch = session["Batch"]
        faculty = session["Faculty"]
        room = session["Room"]

        # Try every available time slot
        for day, period in slots:

            slot = (day, period)

            # -------------------------------------
            # Constraint 1:
            # Same batch cannot have two classes
            # at the same time.
            # -------------------------------------

            if (batch, slot) in batch_busy:
                continue

            # -------------------------------------
            # Constraint 2:
            # Same faculty cannot teach two classes
            # at the same time.
            # -------------------------------------

            if (faculty, slot) in faculty_busy:
                continue

            # -------------------------------------
            # Constraint 3:
            # Same room cannot be used twice
            # at the same time.
            # -------------------------------------

            if (room, slot) in room_busy:
                continue

            # -------------------------------------
            # Assign this class
            # -------------------------------------

            assignment = {
                "Day": day,
                "Period": period,
                "Subject": session["Subject"],
                "Batch": batch,
                "Faculty": faculty,
                "Room": room,
                "Session": session["Session"]
            }

            schedule.append(assignment)

            batch_busy.add((batch, slot))
            faculty_busy.add((faculty, slot))
            room_busy.add((room, slot))

            # -------------------------------------
            # Continue searching
            # -------------------------------------

            if backtrack(index + 1):
                return True

            # -------------------------------------
            # Undo assignment
            # This is the BACKTRACKING step.
            # -------------------------------------

            schedule.pop()

            batch_busy.remove((batch, slot))
            faculty_busy.remove((faculty, slot))
            room_busy.remove((room, slot))

        backtracks += 1

        return False

    # Start search
    success = backtrack(0)

    # ---------------------------------------------
    # Result
    # ---------------------------------------------

    if success:

        result = pd.DataFrame(schedule)

        result = result.sort_values(
            by=[
                "Day",
                "Period",
                "Batch"
            ]
        )

        result = result.reset_index(drop=True)

        return (
            result,
            True,
            nodes,
            backtracks
        )

    return (
        pd.DataFrame(),
        False,
        nodes,
        backtracks
    )


# ---------------------------------------------------------
# SIDEBAR
# ---------------------------------------------------------

st.sidebar.header("⚙️ Timetable Settings")

periods_per_day = st.sidebar.selectbox(
    "Periods per day",
    options=[4, 5, 6, 7, 8],
    index=2
)

max_nodes = st.sidebar.number_input(
    "Maximum search nodes",
    min_value=1000,
    max_value=1000000,
    value=100000,
    step=1000
)


# ---------------------------------------------------------
# INPUT SECTION
# ---------------------------------------------------------

st.header("📝 Enter Subjects")

st.write(
    "Enter the subject, batch/section, faculty, room, "
    "and number of classes required per week."
)

subjects = st.data_editor(
    DEFAULT_SUBJECTS,
    num_rows="dynamic",
    use_container_width=True,
    hide_index=True
)


# ---------------------------------------------------------
# REMOVE COMPLETELY EMPTY ROWS
# ---------------------------------------------------------

empty_rows = (
    (subjects["Subject"].astype(str).str.strip() == "")
    &
    (subjects["Batch"].astype(str).str.strip() == "")
    &
    (subjects["Faculty"].astype(str).str.strip() == "")
    &
    (subjects["Room"].astype(str).str.strip() == "")
)

subjects = subjects.loc[
    ~empty_rows
].copy()


# ---------------------------------------------------------
# GENERATE BUTTON
# ---------------------------------------------------------

if st.button(
    "🚀 Generate Timetable",
    type="primary"
):

    # ---------------------------------------------
    # Validation
    # ---------------------------------------------

    required_columns = [
        "Subject",
        "Batch",
        "Faculty",
        "Room",
        "Classes/week"
    ]

    missing_columns = [
        col
        for col in required_columns
        if col not in subjects.columns
    ]

    if missing_columns:

        st.error(
            "Missing columns: "
            + ", ".join(missing_columns)
        )

        st.stop()

    # ---------------------------------------------
    # Check blank fields
    # ---------------------------------------------

    invalid_rows = []

    for index, row in subjects.iterrows():

        if (
            str(row["Subject"]).strip() == ""
            or str(row["Batch"]).strip() == ""
            or str(row["Faculty"]).strip() == ""
            or str(row["Room"]).strip() == ""
        ):
            invalid_rows.append(index + 1)

    if invalid_rows:

        st.error(
            "Please fill Subject, Batch, Faculty, "
            "and Room for all rows."
        )

        st.stop()

    # ---------------------------------------------
    # Convert classes/week
    # ---------------------------------------------

    try:

        subjects["Classes/week"] = (
            subjects["Classes/week"]
            .astype(int)
        )

    except:

        st.error(
            "Classes/week must contain whole numbers."
        )

        st.stop()

    # ---------------------------------------------
    # Check positive values
    # ---------------------------------------------

    if (
        subjects["Classes/week"] <= 0
    ).any():

        st.error(
            "Classes/week must be greater than 0."
        )

        st.stop()

    # ---------------------------------------------
    # Calculate total required classes
    # ---------------------------------------------

    total_classes = int(
        subjects["Classes/week"].sum()
    )

    unique_batches = (
        subjects["Batch"]
        .astype(str)
        .str.strip()
        .nunique()
    )

    total_slots_per_batch = (
        len(DAYS) * periods_per_day
    )

    total_batch_capacity = (
        unique_batches
        * total_slots_per_batch
    )

    st.info(
        f"Required classes: **{total_classes}**  |  "
        f"Batch capacity: **{total_batch_capacity}**"
    )

    # ---------------------------------------------
    # Quick capacity check
    # ---------------------------------------------

    if total_classes > total_batch_capacity:

        st.error(
            "❌ Timetable cannot be generated. "
            "There are more classes than the available "
            "batch time slots."
        )

        st.stop()

    # ---------------------------------------------
    # Generate timetable
    # ---------------------------------------------

    with st.spinner(
        "Generating timetable..."
    ):

        timetable, success, nodes, backtracks = (
            generate_timetable(
                subjects,
                periods_per_day,
                max_nodes
            )
        )

    # ---------------------------------------------
    # Successful result
    # ---------------------------------------------

    if success:

        st.success(
            "✅ Timetable generated successfully!"
        )

        # -----------------------------------------
        # DAA METRICS
        # -----------------------------------------

        st.subheader("📊 DAA Performance")

        col1, col2, col3 = st.columns(3)

        with col1:
            st.metric(
                "Classes Scheduled",
                len(timetable)
            )

        with col2:
            st.metric(
                "Search Nodes",
                nodes
            )

        with col3:
            st.metric(
                "Backtracks",
                backtracks
            )

        # -----------------------------------------
        # TIMETABLE
        # -----------------------------------------

        st.subheader("📅 Generated Timetable")

        # Create a readable display
        display_data = []

        for day in DAYS:

            for period in range(
                1,
                periods_per_day + 1
            ):

                classes = timetable[
                    (
                        timetable["Day"] == day
                    )
                    &
                    (
                        timetable["Period"] == period
                    )
                ]

                if len(classes) == 0:

                    display_data.append(
                        {
                            "Day": day,
                            "Period": period,
                            "Classes": "Free"
                        }
                    )

                else:

                    class_text = []

                    for _, row in classes.iterrows():

                        class_text.append(
                            f'{row["Batch"]} → '
                            f'{row["Subject"]} '
                            f'| {row["Faculty"]} '
                            f'| {row["Room"]}'
                        )

                    display_data.append(
                        {
                            "Day": day,
                            "Period": period,
                            "Classes": "\n".join(
                                class_text
                            )
                        }
                    )

        timetable_display = pd.DataFrame(
            display_data
        )

        st.dataframe(
            timetable_display,
            use_container_width=True,
            hide_index=True
        )

        # -----------------------------------------
        # DETAILED TABLE
        # -----------------------------------------

        st.subheader(
            "📋 Detailed Timetable"
        )

        detailed = timetable[
            [
                "Day",
                "Period",
                "Batch",
                "Subject",
                "Faculty",
                "Room"
            ]
        ]

        st.dataframe(
            detailed,
            use_container_width=True,
            hide_index=True
        )

        # -----------------------------------------
        # CSV DOWNLOAD
        # -----------------------------------------

        csv_data = detailed.to_csv(
            index=False
        )

        st.download_button(
            label="📥 Download Timetable as CSV",
            data=csv_data,
            file_name="college_timetable.csv",
            mime="text/csv"
        )

        # -----------------------------------------
        # EXCEL DOWNLOAD
        # -----------------------------------------

        excel_buffer = io.BytesIO()

        with pd.ExcelWriter(
            excel_buffer,
            engine="openpyxl"
        ) as writer:

            detailed.to_excel(
                writer,
                index=False,
                sheet_name="Timetable"
            )

        excel_data = (
            excel_buffer.getvalue()
        )

        st.download_button(
            label="📊 Download Timetable as Excel",
            data=excel_data,
            file_name="college_timetable.xlsx",
            mime=(
                "application/vnd.openxmlformats-officedocument."
                "spreadsheetml.sheet"
            )
        )

    # ---------------------------------------------
    # Failed result
    # ---------------------------------------------

    else:

        st.error(
            "❌ No valid timetable could be generated "
            "with the given constraints."
        )

        st.warning(
            "Try increasing the number of periods, "
            "reducing the number of classes, or changing "
            "faculty/room assignments."
        )

        # -----------------------------------------
        # DAA METRICS EVEN WHEN FAILED
        # -----------------------------------------

        st.subheader(
            "📊 DAA Search Information"
        )

        col1, col2 = st.columns(2)

        with col1:
            st.metric(
                "Search Nodes",
                nodes
            )

        with col2:
            st.metric(
                "Backtracks",
                backtracks
            )